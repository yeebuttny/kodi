# -*- coding: utf-8 -*-
## imports

import re, os, urlparse, requests, time, sys
import xbmcplugin, xbmcgui, xbmcaddon
import urllib, urllib2,  cookielib, ssl, zlib, base64
import string, json
import resolveurl as urlresolve

from resources.lib import helpers

def log(msg):
	try:
		msg=str(msg)
	except:
		msg='can\'t convert to string'
	xbmc.log(msg,level=xbmc.LOGNOTICE)
## -==================== END ====================- 
	
def info(msg=" ",title="Info",  time=5000):
	xbmc.executebuiltin("XBMC.Notification(%s,%s,%s)"%(title,msg,str(time)))
## -==================== END ====================- 

##globals
sysaddon                = sys.argv[0]
addon_handle            = int(sys.argv[1])
args                    = urlparse.parse_qs(sys.argv[2][1:])
my_addon                = xbmcaddon.Addon()
my_addon_id             = my_addon.getAddonInfo('id')
my_addon_name           = my_addon.getAddonInfo('name')


MURL							='http://alltube.pl'
def urlGET(u,urlparams=None,data=None,ref=None):

	opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
	context=ssl._create_unverified_context()
	if data:
		data=urllib.urlencode(data)
	if urlparams:
		urlparams=urllib.urlencode(urlparams)
	h=helpers.headers
	h['referer']=ref or u	
	req = urllib2.Request(u,data,headers=h)
	response=opener.open(req,data)
	link=response.read().decode('utf-8')
	response.close()
	ref=u
	return link
## -==================== END ====================- 

def getURL(u,d=None,ref=None,h=None):
	if u:
		h=h or helpers.headers
		h['referer']=ref or u
		s=requests.Session()
		res=s.get(u,params=d, headers=h,timeout=10,stream=False)
		log(res.status_code)
		log(res.headers)
		return res
## -==================== END ====================- 

def postURL(u,d=None,h=None):
	if u:
		if not h:
			h=helpers.headers
		s=requests.Session()
		try:
			res=s.post(u,data=d, headers=h,timeout=10)
			res.close()
		except:
			res=None
		return res
## -==================== END ====================- 

def isCFP(r):
	# if 503 CF protection 
	if  r==None:
		log('CFP check failed - no data to check')
		return None
	return r.status_code==503 and r.headers.get('server','')=='cloudflare'
## -==================== END ====================- 

def solveCFP(l,h=None):
	tries=1
	res=None
	while tries<4:
		r=getURL(l,h=h)
		if not isCFP(r):
			return r
		if r==None:
			break
		form=re.compile('<form id=\"challenge-form\"(.*?)<\/form>',re.DOTALL).findall(r.text)[0]
		formAction=re.compile('action=\"(.*?)\"',re.DOTALL).findall(form)[0]
		formvc=re.compile('<input type=\"hidden\" name=\"jschl_vc\" value=\"(.*?)\"').findall(form)[0]
		formPass=re.compile('<input type=\"hidden\" name=\"pass\" value=\"(.*?)\"').findall(form)[0]
		equation=re.compile('\[CDATA\[(.*?)\/\/\]\]>',re.DOTALL).findall(r.text)[0]
		bv=re.compile('\s*?var.*?:(.*?)};').findall(equation)[0]
		bv=bv.replace('!+[]', '1').replace('!![]','1').replace('[]', '0').replace('(','str(')
		bv=bv.split('/')
		bv=float(eval(bv[0].lstrip('+')))/float(eval(bv[1].lstrip('+')))
		eqs=re.compile('\s*?;(.*?);a\.value').findall(equation)[0]
		eqs=eqs.replace('!+[]', '1').replace('!![]','1').replace('[]', '0')
		eqs=eqs.split(';')
		for i in range(len(eqs)):
			eqs[i]=re.compile('(\w*?\.\w*?)([-+*/]?\=)(.*)').findall(eqs[i])[0]
			ee=eqs[i][2].replace('(','str(').split('/')
			aa=float(eval(ee[0].lstrip('+')))/float(eval(ee[1].lstrip('+')))
			if eqs[i][1]=='-=':
				bv-=aa
			elif eqs[i][1]=='+=':
				bv+=aa
			elif eqs[i][1]=='*=':
				bv*=aa
			elif eqs[i][1]=='/=':
				bv/=aa
			log(bv)
		# 'alltube.pl' len = 10 
		log(bv)
		bv=round(bv,10)+10
		formData={'jschl_vc':formvc,'pass':formPass,'jschl-answer':bv}
		newURL='http://'+l[8:].split('/')[0]
		l2=MURL+formAction+'?jschl_vc=%s&pass=%s&jschl_answer=%s'%(formvc,formPass,bv)
		time.sleep(5)
		res=getURL(l2,ref=l,h=h)
		if res.status_code==200:
			log('CFP solved at '+str(tries)+' time')
			tries=4
		else:
			if tries==3:
				res=None
				log('CFP failed finding solution')
			tries+=1
			log(r.text)
	return res
## -==================== END ====================- 


def MainMenu():
	xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=filmy",listitem=xbmcgui.ListItem("[COLOR orange]Filmy[/COLOR]"),isFolder=True)
	xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=seriale",listitem=xbmcgui.ListItem("[COLOR orange]Seriale[/COLOR]"),isFolder=True)
	xbmcplugin.setContent(addon_handle, 'tvshows')
	xbmcplugin.endOfDirectory(addon_handle)
## -==================== END ====================- 
	
def FILMY():
	xbmcplugin.setContent(addon_handle, 'movies')
	u=MURL+params.get('url','/filmy-online')
	page=int(params.get('page',1))
	u+='/strona['+str(page)+']+'
	l=solveCFP(u)
	if not l==None:
		try:
			rows=re.compile('<div class=\"item-block clearfix\">.*?<div class=\"row\">.*?(<a href=\".*?<\/a>).*?<\/div>.*?<\/div>',re.DOTALL).findall(l.text.encode('utf-8'))
			log(len(rows))
			for r in range(len(rows)):
				img=(re.compile('<img src=\"(.*?)\"',re.DOTALL).findall(rows[r])[0]).replace("thumb","normal")
				title=helpers.PLchar(re.compile('<h3>(.*?)<\/h3>',re.DOTALL).findall(rows[r])[0])
				stitle=re.compile('<div class=\"second-title\">(.*?)<\/div>',re.DOTALL).findall(rows[r])[0]
				details=helpers.PLchar(re.compile('<i class=\"fa fa-microphone\".*?>.*?<\/i>(.*?)<i',re.DOTALL).findall(rows[r])[0])
				desc=helpers.PLchar(re.compile('<p .*?>(.*?)<\/p',re.DOTALL).findall(rows[r])[0])
				link=re.compile('<a href=\"(.*?)\">',re.DOTALL).findall(rows[r])[0]
				li=xbmcgui.ListItem(title+' - [COLOR lime]('+details+')[/COLOR]',thumbnailImage=img)
				info={'plotoutline':desc,'plot':desc}
				li.setInfo( type="video", infoLabels = info )
				li.setProperty('IsPlayable', 'true')
				li.setProperty('fanart_image', img )
				u=sysaddon+"?mode=play&url="+urllib.quote_plus(link)
				xbmcplugin.addDirectoryItem(handle=addon_handle,url=u,listitem=li,isFolder=False)
			xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=filmy&page="+str(page+1),listitem=xbmcgui.ListItem("[COLOR gold]>>> DALEJ >>>[/COLOR]"),isFolder=True)
		except:
			xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=filmy",listitem=xbmcgui.ListItem("[COLOR red]-- error --[/COLOR]"),isFolder=True)		
	xbmcplugin.endOfDirectory(addon_handle)
## -==================== END ====================- 

def SERIALE():
	xbmcplugin.setContent(addon_handle, 'episodes')
	xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=nowelinki",listitem=xbmcgui.ListItem("[COLOR orange]Nowe linki[/COLOR]"),isFolder=True)
	xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=alfabetycznie",listitem=xbmcgui.ListItem("[COLOR orange]Alfabetycznie[/COLOR]"),isFolder=True)
	xbmcplugin.endOfDirectory(addon_handle)
## -==================== END ====================- 

def NOWELINKI():
	xbmcplugin.setContent(addon_handle, 'tvshows')
	u=MURL+params.get('url','/seriale-online')
	page=int(params.get('page',1))
	u+='/'+str(page)
	l=solveCFP(u)
	if not l==None:
		try:
			rows=re.compile('<div class=\"item-block clearfix\">.*?<div class=\"row\">.*?(<a href=\".*?<\/a>).*?<\/div>.*?<\/div>',re.DOTALL).findall(l.text.encode('utf-8'))
			log(len(rows))
			for r in range(len(rows)):
				img=(re.compile('<img src=\"(.*?)\"',re.DOTALL).findall(rows[r])[0]).replace("thumb","normal")
				title=helpers.PLchar(re.compile('<div class=\"top-belt\">(.*?)<\/div>',re.DOTALL).findall(rows[r])[0])
				desc=helpers.PLchar(re.compile('<div class=\"bottom-belt\">(.*?)<\/div>',re.DOTALL).findall(rows[r])[0])
				link=re.compile('<a href=\"(.*?)\">',re.DOTALL).findall(rows[r])[0]
				li=xbmcgui.ListItem(title+' - [COLOR lime]('+desc+')[/COLOR]',thumbnailImage=img)
				info={'plotoutline':title+" | "+desc,'plot':title+" | "+desc}
				li.setInfo( type="video", infoLabels = info )
				li.setProperty('IsPlayable', 'true')
				li.setProperty('fanart_image', img )
				u=sysaddon+"?mode=play&url="+urllib.quote_plus(link)
				xbmcplugin.addDirectoryItem(handle=addon_handle,url=u,listitem=li,isFolder=False)
			xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=nowelinki&page="+str(page+1),listitem=xbmcgui.ListItem("[COLOR gold]>>> DALEJ >>>[/COLOR]"),isFolder=True)
		except:
			xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=nowelinki",listitem=xbmcgui.ListItem("[COLOR red]-- error --[/COLOR]"),isFolder=True)		
	xbmcplugin.endOfDirectory(addon_handle)
## -==================== END ====================- 

def ALFABETYCZNIE():
	xbmcplugin.setContent(addon_handle, 'tvshows')
	u=MURL+params.get('url','/seriale-online/')
	l=solveCFP(u)
	if not l==None:
		try:
			lista=re.compile('<ul class=\"list-unstyled text-white term-list clearfix\">(.*?)<\/ul>',re.DOTALL).findall(l.text.encode('utf-8'))
			letters=re.compile('<li class=\"letter\">(.*?)<\/li>',re.DOTALL).findall(lista[0])
			for l in range(len(letters)):
				items=re.compile('<li data-letter=\"'+letters[l]+'\">(<a.*?<\/a>)<\/li>',re.DOTALL).findall(lista[0])
				li=xbmcgui.ListItem('[COLOR gold] ------------------------ '+letters[l]+' ------------------------ [/COLOR]')
				li.setProperty('IsPlayable', 'false')
				xbmcplugin.addDirectoryItem(handle=addon_handle,url='',listitem=li,isFolder=False)
				for i in range(len(items)):
					try:
						link=re.compile('<a href=\"(.*?)\">',re.DOTALL).findall(items[i])[0]
						title=helpers.PLchar(re.compile('<a href=.*?>(.*?)<\/a>',re.DOTALL).findall(items[i])[0])
						li=xbmcgui.ListItem(title)
						info={}
						li.setInfo( type="video", infoLabels = info )
						li.setProperty('IsPlayable', 'true')
						u=sysaddon+"?mode=serial&url="+urllib.quote_plus(link)
						xbmcplugin.addDirectoryItem(handle=addon_handle,url=u,listitem=li,isFolder=True)
					except:
						log('litera '+letter[l]+' - '+len(items)+' elementow | error')
		except:
			xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=alfabetycznie",listitem=xbmcgui.ListItem("[COLOR red]-- error --[/COLOR]"),isFolder=True)		
	xbmcplugin.endOfDirectory(addon_handle)
## -==================== END ====================-

def SERIAL():
	xbmcplugin.setContent(addon_handle, 'tvshows')
	u=params.get('url','')
	l=solveCFP(u)
	if not l==None:
		try:
			title2=helpers.PLchar(re.compile('<div class=\"col-sm-9\">.*?<h3 class=\"headline\">(.*?)<\/h3>',re.DOTALL).findall(l.text.encode('utf-8'))[0])
			log(title2)
			img=re.compile('<div class=\"col-sm-9\">.*?<img src=\"(.*?)\" alt=\".*?\" class=\"img-responsive\"',re.DOTALL).findall(l.text.encode('utf-8'))[0]
			log(img)
			episodes=re.compile('<li class=\"episode\">(.*?)<\/li>',re.DOTALL).findall(l.text.encode('utf-8'))
			log(len(episodes))

			for e in range(len(episodes)):
				try:
					link=re.compile('<a href=\"(.*?)\">',re.DOTALL).findall(episodes[e])[0]
					title=helpers.PLchar(re.compile('<a href=.*?>(.*?)<\/a>',re.DOTALL).findall(episodes[e])[0])
					li=xbmcgui.ListItem("[COLOR silver]"+title2+"[/COLOR] "+title,thumbnailImage=img)
					info={}
					li.setInfo( type="video", infoLabels = info )
					li.setProperty('IsPlayable', 'true')
					li.setProperty('fanart_image', img )
					u=sysaddon+"?mode=play&url="+urllib.quote_plus(link)
					xbmcplugin.addDirectoryItem(handle=addon_handle,url=u,listitem=li,isFolder=False)
				except:
					log('epizody')
		except:
			xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=serial",listitem=xbmcgui.ListItem("[COLOR red]-- error --[/COLOR]"),isFolder=True)	
	xbmcplugin.endOfDirectory(addon_handle)
## -==================== END ====================-

def PLAY():
	xbmcplugin.setContent(addon_handle, 'movie')
	u=params.get('url','')
	l=solveCFP(u)
	if not l==None:
		t=re.compile('<table class=\"table\">(.*?)<\/table>',re.DOTALL).findall(l.text.encode('utf-8'))[0]
		rows=re.compile('(<tr.*?)<\/tr>',re.DOTALL).findall(t)
		players=[]
		selList=[]
		for r1 in range(len(rows)):
			tds=re.compile('(<td.*?<\/td>)',re.DOTALL).findall(rows[r1])
			pl=re.compile('> (.*?)<\/td>',re.DOTALL).findall(tds[0])[0]
			link=re.compile('<a href=\"(.*?)\" ',re.DOTALL).findall(tds[1])[0]
			kind=re.compile('<td.*?>(.*?)<\/td>',re.DOTALL).findall(tds[3])[0]
			players.append([pl,link])
			selList.append("%s [COLOR lime]%s[/COLOR]" % (pl,kind))
		playfrom=xbmcgui.Dialog().select('Wybor zrodla',selList)
		if playfrom>=0:
			log("Wybrano :"+players[playfrom][0]+" - link: "+players[playfrom][1])
			player(players[playfrom])
	else:
		info("LINK FEATCHING FAILED","E404", time=5000)
	xbmcplugin.endOfDirectory(addon_handle)
## -==================== END ====================-

def player(p):
	pl=p[0]
	link=p[1]
	l=solveCFP(link)
	stream_url=''
	if not l==None:
		try:
			iframesrc=re.compile('<iframe src=\"(.*?)\" ',re.DOTALL).findall(l.text.encode('utf-8'))[0]
			log(l.text.encode('utf-8'))
			if iframesrc.startswith('//'):
				iframesrc = 'http:' + iframesrc
			try:
				stream_url = urlresolve.resolve(iframesrc)
			except Exception,e:
				stream_url=''
				s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny stream_url będzie działał?','Urlresolver ERROR: [%s]'%str(e))
		except:
			log('no iframe found: '+link)
		if stream_url:
			xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
		else:
			return False
		xbmcplugin.endOfDirectory(addon_handle)
## -==================== END ====================-
	
menu={"menu":MainMenu,"filmy":FILMY,"seriale":SERIALE,"nowelinki":NOWELINKI,"alfabetycznie":ALFABETYCZNIE,"serial":SERIAL,"play":PLAY}

def buildItem(label,thumb,typ='video',inf={},playable=False):
	li=xbmcgui.ListItem(label,thumbnailImage=thumb)
	li.setInfo( type=typ, infoLabels = inf )
	li.setProperty('IsPlayable', playable)
	return li

def addItem(u,li,folder=True):
	u=sysaddon+u
	ok=xbmcplugin.addDirectoryItem(handle=addon_handle,url=u,listitem=li,isFolder=folder)
	return ok

## MAIN LOOP ########################################################
params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
mode = params.get('mode', "menu")
log("ALLTUBE: mode - "+mode+" full-args: "+sys.argv[2])
menu[mode]()
## END MAIN LOOP ####################################################
