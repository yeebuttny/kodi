# -*- coding: utf-8 -*-
## imports

import re, os, urlparse, requests, time, sys
import xbmcplugin, xbmcgui, xbmcaddon
import urllib, urllib2,  cookielib, ssl, zlib, base64
import string, json
import resolveurl as urlresolve

from resources.lib import helpers
from resources.lib import common

def route(p):
	action=p.get("action","SerialeCO")
	if action:
		eval(action)(p)
	else:
		SerialeCO(p)
		

def SerialeCO(p):
	baseURL='https://seriale.co'
	seria=p.get('seria', None)
	if seria==None:
		l=common.solveCFP(baseURL)
		if not l==None:
			lista=re.compile('<ul class=\"dpe-flexible-posts\">(.*?)<\/ul>',re.DOTALL).findall(l.text.encode('utf-8'))[0]
			items=re.compile('<li id=\".*?\" class=\".*?\">.*?<a href=\"(.*?)\">.*?<div class=\"title\">(.*?)<\/div>.*?<\/a>.*?<\/li>',re.DOTALL).findall(lista)
			for r in range(len(items)):
				#------------------------------
				common.addDirectoryItem("?mode=serialeco&seria="+urllib.quote_plus(items[r][0]),xbmcgui.ListItem("[COLOR orange]%s[/COLOR]" % items[r][1]),True)
	else:
		l=common.solveCFP(seria)	
		title=re.compile('<span class=\"td-bred-no-url-last\">(.*?)<\/span>').findall(l.text.encode('utf-8'))[0]
		if not l==None:
				fweb=re.compile("<input type=\'hidden\' id=\'fweb\' value=\'(.*?)\'\/>").findall(l.text.encode('utf-8'))[0]
				fid=re.compile("<input type=\'hidden\' id=\'fid\' value=\'(.*?)\'\/>").findall(l.text.encode('utf-8'))[0]
				img=re.compile('<meta name=\"twitter\:image\" content=\"(.*?)\" \/>').findall(l.text.encode('utf-8'))[0]
				sezony=common.post('https://seriale.co/ajax.php',{'serial_info':fweb})
				if not sezony==None:
					sezony=eval(sezony.text)
					#log(sezony)
					for s in sezony:
						for e in sezony[s]:
							sezony[s][e]['tytul']
							li=xbmcgui.ListItem('S'+s+'E'+e+' - [COLOR lime]'+sezony[s][e]['tytul']+'[/COLOR]',thumbnailImage=img)
							li.setInfo( type="video", infoLabels = {} )
							li.setProperty('IsPlayable', 'true')
							li.setProperty('fanart_image', img )
							u="?mode=serialeco&action=PlaySerialeCO&fid=%s&fweb=%s&sezon=%s&odcinek=%s&title=%s" % (fid,fweb,s,e,urllib.quote_plus(title))
							common.addDirectoryItem(u,li,False)

	xbmcplugin.endOfDirectory(common.addon_handle)
## --------------------------------------------------------------------------	
def PlaySerialeCO(p):
	baseURL='http://178.19.110.218/forumserialeco/skrypt/szukaj3.php'
	d={'fid':p.get('fid'),'sezon':p.get('sezon'),'odcinek':p.get('odcinek'),'title':p.get('title')}
	common.log(d)
	sources=common.post(baseURL,d=d)
	if not sources==None:
		src=re.compile("<div class=\'.*?\' url=\'(.*?)\' host=\'(.*?)\' wersja=\'(.*?)\'").findall(sources.text.encode('utf-8'))
		url=[]
		sel=[]
		for s in src:
			common.log(s[0])
			url.append(s[0])
			sel.append('[COLOR gold]%s[/COLOR] | %s' % (s[2],s[1]))
		playfrom=xbmcgui.Dialog().select('Wybor zrodla',sel)
		if playfrom>=0:
			l=common.solveCFP('https://seriale.co/frame.php?src='+url[playfrom])
			if not l==None:
				iframe=re.compile('<iframe src=\"(.*?)\"').findall(l.text.encode('utf-8'))[0]
				try:
					stream_url = urlresolve.resolve(iframe)
				except Exception,e:
					stream_url=''
					s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny stream_url będzie działał?','Urlresolver ERROR: [%s]'%str(e))
				if stream_url:
					xbmcplugin.setResolvedUrl(common.addon_handle, True, xbmcgui.ListItem(path=stream_url))
			else:
				common.info('No iframe found')
			
	xbmcplugin.endOfDirectory(common.addon_handle)
## --------------------------------------------------------------------------

## --------------------------------------------------------------------------
