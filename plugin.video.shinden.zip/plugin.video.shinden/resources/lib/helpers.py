# -*- coding: utf-8 -*-
import xbmcaddon

headers = {
				'authority': 'shinden.pl',
				'pragma': 'no-cache','cache-control': 'no-cache',
				'upgrade-insecure-requests': '1',
				'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36 OPR/54.0.2952.71',
				'dnt': '1',
				'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
				'accept-encoding': 'identity',
				'accept-language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7'
				}
				
headersXHR={
'user-agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36 OPR/55.0.2994.44',
'pragma':'no-cache','cache-control': 'no-cache',
'origin':'https://shinden.pl','X-Requested-With': 'XMLHttpRequest',
'accept-encoding':'initial'
}

headersXHR2={
'user-agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36 OPR/55.0.2994.44',
'pragma':'no-cache','cache-control': 'no-cache',
'origin':'https://shinden.pl','X-Requested-With': 'XMLHttpRequest',
'accept-encoding':'identity', 'authority':'api4.shinden.pl','dnt':'1','accept':'*/*'
}

def getListOptions():
	add= xbmcaddon.Addon()
	# standard for listing
	standardListOptions={'type': 'contains','search':'', 
								'genres': 'e130;e234;e364;e380;e263;e207','genres-type': 'all',
								'year_from':'','year_to':'', 
								'start_date_precision': '3',
								'series_status[0]': 'Currently Airing',
								'series_status[1]': 'Finished Airing',
								'series_length[2]': 'less_7',
								'series_length[3]': '7_to_18',
								'series_length[4]': '19_to_27',
								'series_length[5]': '28_to_48',
								'series_length[6]': 'over_48',
								'series_number[0]': 'only_1',
								'series_number[1]': '2_to_14',
								'series_number[2]': '15_to_28',
								'series_number[3]': '29_to_100',
								'series_number[4]': 'over_100',
								'series_number_from':'','series_number_to':'' ,
								'one_online': 'true',
								'sort_by': 'ranking-rate','sort_order': 'desc',
								}

	seriesType=[]
	if add.getSetting('series_type_tv')=='TV':
		seriesType.append('TV')
	if add.getSetting('series_type_ova')=='OVA':
		seriesType.append('OVA')
	if add.getSetting('series_type_movie')=='MOVIE':
		seriesType.append('Movie')
	if add.getSetting('series_type_special')=='SPECIAL':
		seriesType.append('Special')
	if add.getSetting('series_type_ona')=='ONA':
		seriesType.append('ONA')
	for i in range(len(seriesType)):
		standardListOptions['series_type['+i+']']=seriesType[i]
	letter=add.getSetting('letter')
	if not (letter=='brak'):
		standardListOptions['letter']=letter[0]
	sortBy=['desc','ranking-rate','multimedia']
	standardListOptions['sort_by']=sortBy[int(add.getSetting('sort_by'))]
	sortOrder=['desc','asc']
	standardListOptions['sort_order']=sortOrder[int(add.getSetting('sort_order'))]
	return standardListOptions
	
def getSearchOptions():
	add= xbmcaddon.Addon()