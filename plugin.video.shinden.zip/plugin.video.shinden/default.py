# -*- coding: utf-8 -*-
## imports

import re, os, urlparse, requests, time, sys
import xbmcplugin, xbmcgui, xbmcaddon
import urllib, urllib2,  cookielib, ssl, zlib, base64
import string, json

from resources.lib import helpers




def log(msg):
	try:
		msg=str(msg)
	except:
		msg='can\'t convert to string'
	xbmc.log(msg,level=xbmc.LOGNOTICE)
	
def info(msg=" ",title="Info",  time=5000):
	xbmc.executebuiltin("XBMC.Notification(%s,%s,%s)"%(title,msg,str(time)))


##globals
sysaddon                = sys.argv[0]
addon_handle            = int(sys.argv[1])
args                    = urlparse.parse_qs(sys.argv[2][1:])
my_addon                = xbmcaddon.Addon()
my_addon_id             = my_addon.getAddonInfo('id')
my_addon_name           = my_addon.getAddonInfo('name')

#certificate=my_addon.getAddonInfo('path').decode('utf-8')+ os.path.sep +'certs.pem'


MURL							='https://shinden.pl'
def urlGET(u,urlparams=None,data=None,ref=None):

	opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
	context=ssl._create_unverified_context()
	if data:
		data=urllib.urlencode(data)
	if urlparams:
		urlparams=urllib.urlencode(urlparams)
	h=helpers.headers
	h['referer']=ref or u	
	req = urllib2.Request(u,data,headers=h)
	#try:
	response=opener.open(req,data)
	link=response.read().decode('utf-8')
	response.close()
	#except:
	#	link=None
	#	log('- no link data -')
	ref=u
	return link

def getURL(u,d=None,ref=None,h=None):
	if u:
		h=h or helpers.headers
		h['referer']=ref or u
		s=requests.Session()
		#s.cert=certificate
		#try:
		#s.head(u,verify=False)
		res=s.get(u,params=d, headers=h,timeout=10,stream=False)
		log(res.status_code)
		log(res.headers)
		#res.close()
		#except:
		#	res=None
		return res
def postURL(u,d=None,h=None):
	if u:
		if not h:
			h=helpers.headers
		s=requests.Session()
		try:
			res=s.post(u,data=d, headers=h,timeout=10)
			res.close()
		except:
			res=None
		return res

def isCFP(r):
	# if 503 CF protection 
	if  r==None:
		log('CFP check failed - no data to check')
		return None
	return r.status_code==503 and r.headers.get('server','')=='cloudflare'

def solveCFP(l,h=None):
	tries=1
	res=None
	while tries<4:
		r=getURL(l,h=h)
		if not isCFP(r):
			return r
		if r==None:
			break
		form=re.compile('<form id=\"challenge-form\"(.*?)<\/form>',re.DOTALL).findall(r.text)[0]
		formAction=re.compile('action=\"(.*?)\"',re.DOTALL).findall(form)[0]
		formvc=re.compile('<input type=\"hidden\" name=\"jschl_vc\" value=\"(.*?)\"').findall(form)[0]
		formPass=re.compile('<input type=\"hidden\" name=\"pass\" value=\"(.*?)\"').findall(form)[0]
		equation=re.compile('\[CDATA\[(.*?)\/\/\]\]>',re.DOTALL).findall(r.text)[0]
		bv=re.compile('\s*?var.*?:(.*?)};').findall(equation)[0]
		bv=bv.replace('!+[]', '1').replace('!![]','1').replace('[]', '0').replace('(','str(')
		bv=bv.split('/')
		bv=float(eval(bv[0].lstrip('+')))/float(eval(bv[1].lstrip('+')))
		eqs=re.compile('\s*?;(.*?);a\.value').findall(equation)[0]
		eqs=eqs.replace('!+[]', '1').replace('!![]','1').replace('[]', '0')
		eqs=eqs.split(';')
		for i in range(len(eqs)):
			eqs[i]=re.compile('(\w*?\.\w*?)([-+*/]?\=)(.*)').findall(eqs[i])[0]
			ee=eqs[i][2].replace('(','str(').split('/')
			aa=float(eval(ee[0].lstrip('+')))/float(eval(ee[1].lstrip('+')))
			if eqs[i][1]=='-=':
				bv-=aa
			elif eqs[i][1]=='+=':
				bv+=aa
			elif eqs[i][1]=='*=':
				bv*=aa
			elif eqs[i][1]=='/=':
				bv/=aa
			log(bv)
		# 'shinden.pl' len = 10 
		log(bv)
		bv=round(bv,10)+10
		formData={'jschl_vc':formvc,'pass':formPass,'jschl-answer':bv}
		newURL='https://'+l[8:].split('/')[0]
		l2=MURL+formAction+'?jschl_vc=%s&pass=%s&jschl_answer=%s'%(formvc,formPass,bv)
		time.sleep(5)
		res=getURL(l2,ref=l,h=h)
		if res.status_code==200:
			log('CFP solved at '+str(tries)+' time')
			tries=4
		else:
			if tries==3:
				res=None
				log('CFP failed finding solution')
			tries+=1
			log(r.text)
	return res



def MainMenu():
	xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=lista",listitem=xbmcgui.ListItem("[COLOR orange]Lista[/COLOR]"),isFolder=True)
	xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=lista&search=1",listitem=xbmcgui.ListItem("[COLOR orange]Szukaj[/COLOR]"),isFolder=True)
	xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=settings",listitem=xbmcgui.ListItem("[COLOR orange]Ustawienia[/COLOR]"),isFolder=True)
	xbmcplugin.setContent(addon_handle, 'tvshows')
	xbmcplugin.endOfDirectory(addon_handle)
	
def Lista():
	u=MURL+params.get('url','/titles')
	search=params.get('search',None)
	if search=='1':
		p=helpers.getListOptions()
		p['search']=xbmcgui.Dialog().input('Wyszukaj..')
		log(p['search'])
	else:
		p=helpers.getListOptions()
		p['page']=int(params.get('page',1))
	u+='?'+urllib.urlencode(p)	
	l=solveCFP(u)
	if not l==None:
		try:
			m=re.compile('<section class=\"title-table\">.*?<article>(.*?)<\/article>',re.DOTALL).findall(l.text.encode('utf-8'))
			rows=re.compile('<ul class=\"div-row\">(.*?<li class=\"rate-top\" title=\"Ocena TOP\">.*?<\/li>.*?)<\/ul>',re.DOTALL).findall(m[0])
			for r in range(len(rows)):
				img=re.compile('<li class=\"cover-col\">.*?<a href=\"(.*?)\"',re.DOTALL).findall(rows[r])[0]
				title=re.compile('<h3>.*?>(.*?)<\/a>',re.DOTALL).findall(rows[r])[0]
				link=re.compile('<h3>.*?<a href=\"(.*?)\">',re.DOTALL).findall(rows[r])[0]
				tags=string.join(re.compile('<li.*?<a data-tag-id.*?>(.*?)<\/a>',re.DOTALL).findall(rows[r]),',')
				try:
					nEE=re.compile('<li class=\"episodes-col\" title=\"(.*?)\">',re.DOTALL).findall(rows[r])[0]
				except:
					nEE='0 x 0min'
				nE=[re.compile('<li class=\"episodes-col\".*?>(.*?)<',re.DOTALL).findall(rows[r])[0],nEE]
				kind=re.compile('<li class=\"title-kind-col\">(.*?)<',re.DOTALL).findall(rows[r])[0]
				ocena=re.compile('<li class=\"rate-top\".*?>(.*?)<',re.DOTALL).findall(rows[r])[0]
				##addFolder(title,link,img,tags,nE,kind,ocena,sendto)
				## add item
				link+='/all-episodes'
				noe=int(nE[0])
				try:
					dur=int(re.compile('x(.*?)min').findall(nE[1])[0])*60
				except:
					dur=0
				li=xbmcgui.ListItem('[COLOR silver]('+kind+')[/COLOR] '+title+' - [COLOR lime]('+(nE[1] if nE[1] else nE[0])+')[/COLOR]',label2='test',thumbnailImage=MURL+img)
				info={'rating':ocena,'genre':tags,'episode':noe,'duration':dur}
				li.setInfo( type="video", infoLabels = info )
				li.setProperty('IsPlayable', 'true')
				li.setProperty('fanart_image', MURL+img )
				u=sysaddon+"?mode=seria&url="+urllib.quote_plus(link)
				xbmcplugin.addDirectoryItem(handle=addon_handle,url=u,listitem=li,isFolder=True)
			xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=lista&page="+str(p['page']+1),listitem=xbmcgui.ListItem("[COLOR gold]>>> DALEJ >>>[/COLOR]"),isFolder=True)
		except:
			xbmcplugin.addDirectoryItem(handle=addon_handle,url=sysaddon+"?mode=lista",listitem=xbmcgui.ListItem("[COLOR red]-- error --[/COLOR]"),isFolder=True)		
		
	xbmcplugin.setContent(addon_handle, 'tvshows')
	xbmcplugin.endOfDirectory(addon_handle)
def seria():
	u=MURL+params.get('url','')
	l=solveCFP(u)
	if not l==None:
		##getEpizodes(s,'playEpizod')
		m=re.compile('<tbody class=\"list-episode-checkboxes\">(.*?)<\/tbody>',re.DOTALL).findall(l.text.encode('utf-8'))
		img=re.compile('<img class=\"info-aside-img\" src=\"(.*?)\"',re.DOTALL).findall(l.text.encode('utf-8'))[0]
		mtitle=re.compile('<h1 class=\"page-title\">Anime: (.*?)<\/h1>').findall(l.text.encode('utf-8'))[0]
		if m:
			rows=re.compile('<tr>(.*?)<\/tr>',re.DOTALL).findall(m[0])
		if rows:
			for r in range(len(rows)):
				nE=re.compile('<td>(\d*?)<\/td>',re.DOTALL).findall(rows[r])[0]
				title=re.compile('<td class=\"ep-title\">(.*?)<\/td>',re.DOTALL).findall(rows[r])[0]
				title2=' | ' if title else ''
				title=mtitle+title2+title
				isOnline=re.compile('<i class=\"fa fa-fw fa-(\w*?)\">',re.DOTALL).findall(rows[r])[0]
				data=re.compile('\"ep-date\">(.*?)<\/td>',re.DOTALL).findall(rows[r])[0]
				link=re.compile('<a href=\"(.*?)\"',re.DOTALL).findall(rows[r])[0]
				addLink(title,nE,link,img,data,'playEpizod',isOnline)	
	
	xbmcplugin.setContent(addon_handle, 'episodes')		
	xbmcplugin.endOfDirectory(addon_handle)

def playEpizod():
	xbmcplugin.setContent(addon_handle, 'movie')
	u=MURL+params.get('url','')
	l=solveCFP(u)
	if not l==None:
		m=re.compile('<table class=\"data-view-table-strips data-view-table-big data-view-hover\">(.*?)<\/table>',re.DOTALL).findall(l.text.encode('utf-8'))[0]
		m1=re.compile('<tbody>(.*?)<\/tbody>',re.DOTALL).findall(m)
		rows=re.compile('<tr>(.*?)<\/tr>',re.DOTALL).findall(m1[0])
		KEY=re.compile("_Storage\.basic =  '(.*?)';",re.DOTALL).findall(l.text.encode('utf-8'))[0]
		XHR=re.compile("_Storage\.XHRService = '\/\/(.*?)';",re.DOTALL).findall(l.text.encode('utf-8'))[0]
		players=[]
		selList=[]
		for r in range(len(rows)):
			pl=re.compile('<td class=\"ep-pl-name\">.*?([\w\s\d]*?)<\/td>',re.DOTALL).findall(rows[r])[0] or 0
			audio=re.compile('<td class=\"ep-pl-alang\">.*?<span class=\"mobile-hidden\">(.*?)<\/span>',re.DOTALL).findall(rows[r])[0] or 0
			subs=re.compile('<td class=\"ep-pl-slang\">.*?<span class=\"mobile-hidden\">(.*?)<\/span>',re.DOTALL).findall(rows[r])[0] or 0
			res=re.compile('<td class=\"ep-pl-res\">.*?<\/span>(.*?)<\/td>',re.DOTALL).findall(rows[r])[0] or 0
			id=re.compile('\"online_id\":\"(.*?)\"',re.DOTALL).findall(rows[r])[0] or 0
			players.append([pl,id])
			selList.append("%s [COLOR blue]%s[/COLOR] A:%s N:%s" % (pl,res,audio,subs))
		playfrom=xbmcgui.Dialog().select('Wybor zrodla',selList)
		if playfrom>=0:
			player(players[playfrom],KEY,XHR)
	else:
		info("LINK FEATCHING FAILED","E404", time=5000)
	xbmcplugin.endOfDirectory(addon_handle)

def player(p,k,x):
	pl=p[0]
	id=p[1]
	key=k
	XHR=x
	rURL="https://"+XHR+"/"+id+"/"
	data={"auth":key}
	log('id: '+id+ " key: "+key)
	s=request(rURL,data)
	if s:
	#l=solveCFP(rURL+'player_load?'+urllib.urlencode(data),h=helpers.headersXHR)
	#if not l==None:
		m=re.compile('<iframe.*?src=\"\/\/(.*?)\"',re.DOTALL).findall(s)[0]
		log('resolving: '+m)
		# suported by code
		# ebd.cda.pl openload
		if 'cda' in m:
			log('cda') 
			resolveCDA(m)
		elif 'openload' in m:
			resolveOPENLOAD(m)
		elseif 'fb' in m:
			resolveFB(m)
		else:
			info('Player nie jest obslugiwany','PLAYER ERROR',200)
	else:
		info("Brak odpowiedzi XHR, wiecej w log-u.","Upss...")

def request(l,d):
	s=requests.Session()
	head = {'authority': 'shinden.pl','user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36 OPR/54.0.2952.71','X-Requested-With': 'XMLHttpRequest','Host': 'shinden.pl','contentType': 'application/x-www-form-urlencoded; charset=UTF-8','Referer': 'https://shinden.pl',	
				'pragma': 'no-cache','cache-control': 'no-cache',
				'upgrade-insecure-requests': '1',				
				'dnt': '1',
				'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
				'accept-encoding': 'identity',
				'accept-language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7'}
	#try:
	r=s.get(l+"player_load", params=d, headers=head,timeout=10)
	r.close()
	info('Pobieram dane playera','')
	time.sleep(int(r.text))
	d['width']="800"
	r=s.get(l+"player_show", params=d, headers=head,timeout=10)
	r.close()
	text=r.text.encode('utf-8')
	#except:
	#	log('nieudane request')
	#	text=''
	return text

def request2(l,d=None):
	s=requests.Session()
	head = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36','X-Requested-With': 'XMLHttpRequest','Host': 'openload.co','contentType': 'application/x-www-form-urlencoded; charset=UTF-8','Referer': 'https://openload.co'}
	r=None
	try:
		r=s.get(l, params=d, headers=head,timeout=10)
	except:
		log('nieudane request OPENLOAD')
	return r

def resolveCDA(l):
	s=getURL("https://"+l)
	if not s==None:
		m=re.compile('<div id=\".*?\" player_data=\'(.*?)\' tabindex').findall(s.text.encode('utf-8'))[0]
		if m:
			vl=re.compile('\"file\":\"(.*?)\"').findall(m)[0]
			vl=vl.replace('\\','')
			xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=vl))
	else:
		return False
	xbmcplugin.endOfDirectory(addon_handle)

def resolveFB(l):
	s=getURL("https://"+l)
	if not s==None:
		m=re.compile('<video.*?src=\"(.*?)\"').findall(s.text.encode('utf-8'))[0]
		if m:
			##vl=re.compile('\"file\":\"(.*?)\"').findall(m)[0]
			##vl=vl.replace('\\','')
			xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=vl))
	else:
		return False
	xbmcplugin.endOfDirectory(addon_handle)

def resolveOTHER(l):
	link=''
	try:
		link=resolveurl.resolve("https://"+l)
	except:
		info('cos wiecej w logu','Blad resolveurl')
	if link:
		xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=link))
	

def resolveOPENLOAD(l):
	mediaid=l.split("/")
	#//openload.co/embed/T46sXRDbTos/
	mediaid=mediaid[len(mediaid)-2]
	status=requests.get('https://api.openload.co/1/file/info?file='+mediaid)
	if status:
		if status.json().get('status')==200:
			status=requests.get('https://api.openload.co/1/streaming/get?file='+mediaid)
			if status:
				if status.json().get('status')==200:
					link=status.json().get('result').get('url')
					if link:
						xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=link))
					else:
						info('OPENLOAD - link not found','',200)
				else:
					info(status.json().get('msg'))
			else:
				info('openload - request error','',200)
		else:
			info(status.json().get('msg'))
	else:
		info('openload - request error','',200)
	return 0
	
def addLink(title,nE,link,img,data,sendto,isOnline):
	l=link
	li=xbmcgui.ListItem('[COLOR gray]#'+str(nE)+'('+str(data)+') [/COLOR] [COLOR %s]'%('' if isOnline=='check' else 'red')+title+'[/COLOR]',thumbnailImage=MURL+img)
	
	info={'plotoutline':'data emisji: '+data,'plot':'data emisji: '+data,'year':int(nE),'episode':int(nE)}
	li.setInfo( type="video", infoLabels = info )
	li.setProperty('IsPlayable', 'true')
	u=sysaddon+"?mode="+str(sendto)+"&url="+urllib.quote_plus(l)
	ok=xbmcplugin.addDirectoryItem(handle=addon_handle,url=u,listitem=li,isFolder=False)##change to False
	return ok

def Settings():
	my_addon.openSettings()
	
menu={"menu":MainMenu,"lista":Lista,'settings':Settings,'seria':seria,'playEpizod':playEpizod}

# Lista Anime
# - contex showsettings
# Szukaj
# - contex showsettings

# ?mode=mode



def buildItem(label,thumb,typ='video',inf={},playable=False):
	li=xbmcgui.ListItem(label,thumbnailImage=thumb)
	li.setInfo( type=typ, infoLabels = inf )
	li.setProperty('IsPlayable', playable)
	return li

def addItem(u,li,folder=True):
	u=sysaddon+u
	ok=xbmcplugin.addDirectoryItem(handle=addon_handle,url=u,listitem=li,isFolder=folder)
	return ok
	



## MAIN LOOP ########################################################
params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
mode = params.get('mode', "menu")
log("Shinden: mode - "+mode+" full-args: "+sys.argv[2])
menu[mode]()
## END MAIN LOOP ####################################################
